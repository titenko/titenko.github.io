---
title: Donate
permalink: "/donate/"
layout: page
---

<p style="text-align:center"><strong>Пожертвуйте на кофе ☕️&nbsp;</strong></p>
<div paypal style="text-align:center">
<a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=MJXSFFF79A8DY" style="text-decoration:none;"><span class="paypal-logo" style="font-family: Verdana, Tahoma; font-weight: bold; font-size: 28px;"><i style="color: #000; text-shadow: 1px 1px 1px #fff;">Donate </i><i style="color: #253b80; text-shadow: 1px 1px 1px #fff;">Pay</i><i style="color: #179bd7; text-shadow: 1px 1px 1px #fff;">Pal</i></span></a></div>
<hr>
 {% include disqus.html %}
